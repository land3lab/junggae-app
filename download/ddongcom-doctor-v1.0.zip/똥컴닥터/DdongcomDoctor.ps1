﻿# =====================================================================
#  똥컴닥터 v1.0  —  랜드3 연구소 (Land3 Lab)
#  "아들이 쓰던 10년 전 컴퓨터도 쌩쌩하게"
#  진단 → 질문 3개 → 처방전(A·B·C) → 처방 A 자동 실행 → 전후 비교 → 리포트
#  Windows PowerShell 5.1 + WinForms (Windows 10/11 기본 탑재, 설치 불필요)
# =====================================================================

# ---------------- 설정: 사무소 정보 · 부품 참고가 (필요시 수정) ----------------
$Config = [ordered]@{
    AppName      = '똥컴닥터'
    Version      = '1.0'
    Office       = '랜드3 연구소 (Land3 Lab)'
    Person       = '길문수 공인중개사 · 일반행정사'
    Phone        = '02-882-1009'
    Address      = '서울 관악구 관악로6길 99 (미스터홈즈 관악센터)'
    PriceNote    = '2026년 하반기 참고가입니다. 메모리·SSD 값이 2025년 말부터 크게 올라 변동이 심하니, 구매 전 다나와 등에서 꼭 다시 확인하세요.'
    PriceSsdNew  = '신품 SATA SSD 500GB 약 7~10만원'
    PriceSsdUsed = '중고 SATA SSD 256GB 약 3~5만원'
    PriceRamNew  = '신품 8GB 1개 약 4~7만원'
    PriceRamUsed = '중고 8GB 1개 약 2~4만원 (DDR3는 1~2만원)'
}

# ---------------- 관리자 권한으로 다시 실행 ----------------
$script:IsAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $script:IsAdmin -and -not ($args -contains '-NoElevate')) {
    try {
        Start-Process -FilePath 'powershell.exe' -Verb RunAs -ErrorAction Stop `
            -ArgumentList @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', "`"$PSCommandPath`"", '-NoElevate')
        exit
    } catch {
        # 사용자가 권한 요청을 거절 → 제한 모드(진단·리포트만)로 계속
    }
}

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
try {
    Add-Type -Name Win -Namespace DdongcomNative -ErrorAction Stop -MemberDefinition @'
[DllImport("kernel32.dll")] public static extern IntPtr GetConsoleWindow();
[DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
'@
    [void][DdongcomNative.Win]::ShowWindow([DdongcomNative.Win]::GetConsoleWindow(), 0)
} catch {}

$script:DataDir = Join-Path $env:LOCALAPPDATA 'DdongcomDoctor'
if (-not (Test-Path $script:DataDir)) { New-Item -ItemType Directory -Path $script:DataDir -Force | Out-Null }
$script:BaselineFile = Join-Path $script:DataDir 'baseline.json'
$script:UndoFile = Join-Path $script:DataDir 'undo_last.json'

$script:Diag = $null          # 지금 진단
$script:Baseline = $null      # 처음 진단(기준)
$script:Rx = $null            # 처방전
$script:StartupItems = @()
$script:StartupView = @()
$script:BloatView = @()
$script:ActionLog = New-Object System.Collections.ArrayList

$C_RED = [System.Drawing.Color]::FromArgb(200, 40, 40)
$C_ORANGE = [System.Drawing.Color]::FromArgb(214, 110, 0)
$C_GREEN = [System.Drawing.Color]::FromArgb(30, 135, 60)
$C_BRAND = [System.Drawing.Color]::FromArgb(247, 114, 53)
$C_CHAR = [System.Drawing.Color]::FromArgb(35, 41, 43)

# =====================================================================
#  공통 도우미
# =====================================================================
function Format-Size([double]$bytes) {
    if ($bytes -ge 1GB) { return ('{0:N1} GB' -f ($bytes / 1GB)) }
    if ($bytes -ge 1MB) { return ('{0:N0} MB' -f ($bytes / 1MB)) }
    return ('{0:N0} KB' -f ($bytes / 1KB))
}

function Get-FolderSize([string]$path) {
    if (-not $path -or -not (Test-Path -LiteralPath $path)) { return [int64]0 }
    $s = (Get-ChildItem -LiteralPath $path -Recurse -Force -File -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum
    if ($s) { return [int64]$s } else { return [int64]0 }
}

function HtmlEnc([string]$s) { return [System.Net.WebUtility]::HtmlEncode($s) }

function Write-Log([string]$msg) {
    $line = '[{0}] {1}' -f (Get-Date -Format 'HH:mm:ss'), $msg
    [void]$script:ActionLog.Add($line)
    if ($script:txtLog) {
        $script:txtLog.AppendText($line + "`r`n")
        [System.Windows.Forms.Application]::DoEvents()
    }
}

function Set-Status([string]$msg) {
    if ($script:lblStatus) { $script:lblStatus.Text = $msg; [System.Windows.Forms.Application]::DoEvents() }
}

# =====================================================================
#  진단
# =====================================================================
function Get-RamType($mods) {
    $map = @{ 20 = 'DDR'; 21 = 'DDR2'; 24 = 'DDR3'; 26 = 'DDR4'; 29 = 'LPDDR3'; 30 = 'LPDDR4'; 34 = 'DDR5'; 35 = 'LPDDR5' }
    foreach ($m in $mods) { $t = [int]$m.SMBIOSMemoryType; if ($map.ContainsKey($t)) { return $map[$t] } }
    foreach ($m in $mods) { $t = [int]$m.MemoryType; if ($map.ContainsKey($t)) { return $map[$t] } }
    $sp = ($mods | Measure-Object -Property Speed -Maximum).Maximum
    if ($sp -ge 4800) { return 'DDR5(추정)' }
    if ($sp -ge 2133) { return 'DDR4(추정)' }
    if ($sp -ge 800) { return 'DDR3(추정)' }
    return '확인 불가'
}

function Get-BootInfo {
    try {
        $e = Get-WinEvent -FilterHashtable @{ LogName = 'Microsoft-Windows-Diagnostics-Performance/Operational'; Id = 100 } -MaxEvents 1 -ErrorAction Stop
        $x = [xml]$e.ToXml()
        $bt = ($x.Event.EventData.Data | Where-Object { $_.Name -eq 'BootTime' }).'#text'
        if ($bt) { return @{ Seconds = [math]::Round([double]$bt / 1000, 1); When = $e.TimeCreated } }
    } catch {}
    return $null
}

function Get-PowerPlan {
    $o = (powercfg /getactivescheme 2>$null | Out-String)
    if ($o -match '([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})\s*\((.+)\)') {
        return @{ Guid = $matches[1]; Name = $matches[2].Trim() }
    }
    return @{ Guid = ''; Name = '확인 불가' }
}

# 시작프로그램 끄기 추천 / 유지 권장 목록
$script:SuggestOff = 'Steam|Discord|Spotify|Epic ?Games|EpicGamesLauncher|Skype|Zoom|iTunesHelper|AdobeARM|Adobe.*Updat|CCleaner|uTorrent|BitTorrent|Battle\.net|Origin|EADesktop|Ubisoft|MicrosoftEdgeAutoLaunch|Opera|Cortana|Dropbox|GoogleDrive|Wallpaper|RiotClient|LGHUB|Razer|Overwolf|Teams'
$script:KeepOn = 'SecurityHealth|Defender|Realtek|RtkAud|igfx|Intel|AMD|Radeon|NVIDIA|Synaptics|ETD|Elan|AhnLab|\bV3|nProtect|TouchEn|Veraport|IPinside|AnySign|Delfino|CrossEX|INISAFE|MagicLine|Wizvera|KSign|Xecure|Printer|Bluetooth|Audio|Hotkey|Fn ?Key|Samsung ?Settings|LG ?Control'

function Get-ApprovedEnabled([string]$apprPath, [string]$name) {
    try { $v = (Get-Item -LiteralPath $apprPath -ErrorAction Stop).GetValue($name) } catch { return $true }
    if ($v -is [byte[]] -and $v.Length -gt 0) { return (($v[0] -band 1) -eq 0) }
    return $true
}

function Get-StartupItems {
    $list = New-Object System.Collections.ArrayList
    $defs = @(
        @{ Loc = '사용자(레지스트리)'; Run = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run'; Appr = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\Run' },
        @{ Loc = '모든 사용자(레지스트리)'; Run = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run'; Appr = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\Run' },
        @{ Loc = '모든 사용자(32비트)'; Run = 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Run'; Appr = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\Run32' }
    )
    foreach ($d in $defs) {
        if (-not (Test-Path $d.Run)) { continue }
        $key = Get-Item -LiteralPath $d.Run
        foreach ($n in $key.GetValueNames()) {
            if ([string]::IsNullOrEmpty($n)) { continue }
            [void]$list.Add([pscustomobject]@{
                    Name = $n; Command = [string]$key.GetValue($n); Location = $d.Loc; ApprPath = $d.Appr
                    Enabled = (Get-ApprovedEnabled $d.Appr $n); Category = ''
                })
        }
    }
    $folders = @(
        @{ Loc = '사용자(시작 폴더)'; Path = [Environment]::GetFolderPath('Startup'); Appr = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\StartupFolder' },
        @{ Loc = '모든 사용자(시작 폴더)'; Path = [Environment]::GetFolderPath('CommonStartup'); Appr = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\StartupFolder' }
    )
    foreach ($f in $folders) {
        if (-not $f.Path -or -not (Test-Path -LiteralPath $f.Path)) { continue }
        Get-ChildItem -LiteralPath $f.Path -File -Force -ErrorAction SilentlyContinue | Where-Object { $_.Name -ne 'desktop.ini' } | ForEach-Object {
            [void]$list.Add([pscustomobject]@{
                    Name = $_.Name; Command = $_.FullName; Location = $f.Loc; ApprPath = $f.Appr
                    Enabled = (Get-ApprovedEnabled $f.Appr $_.Name); Category = ''
                })
        }
    }
    foreach ($it in $list) {
        $txt = $it.Name + ' ' + $it.Command
        if ($txt -match $script:KeepOn) { $it.Category = 'keep' }
        elseif ($txt -match $script:SuggestOff) { $it.Category = 'off' }
        else { $it.Category = 'normal' }
    }
    return , $list.ToArray()
}

$script:BloatList = [ordered]@{
    'Microsoft.BingNews' = '뉴스'; 'Microsoft.BingWeather' = '날씨'; 'Microsoft.GetHelp' = '도움 받기'; 'Microsoft.Getstarted' = '팁'
    'Microsoft.MicrosoftSolitaireCollection' = '카드 게임(솔리테어)'; 'Microsoft.MicrosoftOfficeHub' = 'Office 광고 허브'; 'Microsoft.People' = '사람'
    'Microsoft.SkypeApp' = 'Skype'; 'Microsoft.WindowsFeedbackHub' = '피드백 허브'; 'Microsoft.XboxApp' = 'Xbox'; 'Microsoft.GamingApp' = 'Xbox 앱'
    'Microsoft.XboxGamingOverlay' = 'Xbox Game Bar'; 'Microsoft.XboxGameOverlay' = 'Xbox 오버레이'; 'Microsoft.XboxSpeechToTextOverlay' = 'Xbox 음성 오버레이'
    'Microsoft.Xbox.TCUI' = 'Xbox TCUI'; 'Microsoft.ZuneMusic' = 'Groove 음악'; 'Microsoft.ZuneVideo' = '영화 및 TV'; 'Microsoft.MixedReality.Portal' = '혼합 현실 포털'
    'Microsoft.Microsoft3DViewer' = '3D 뷰어'; 'Microsoft.3DBuilder' = '3D 빌더'; 'Microsoft.Print3D' = '3D 프린트'; 'Microsoft.WindowsMaps' = '지도'
    'Microsoft.Messaging' = '메시징'; 'Microsoft.OneConnect' = '모바일 요금제'; 'Clipchamp.Clipchamp' = 'Clipchamp 영상편집'; 'MicrosoftTeams' = 'Teams(개인용)'
    'Microsoft.549981C3F5F10' = 'Cortana'
}
$script:BloatWild = [ordered]@{ '*CandyCrush*' = '캔디크러시 게임'; '*BubbleWitch*' = '버블위치 게임'; '*MarchofEmpires*' = '게임 광고 앱'; '*Disney*' = '디즈니 앱'; '*TikTok*' = '틱톡'; '*Roblox*' = '로블록스' }

function Get-BloatApps {
    $res = New-Object System.Collections.ArrayList
    try { $all = @(Get-AppxPackage -ErrorAction Stop) } catch { return , @() }
    foreach ($p in $all) {
        $label = $null
        if ($script:BloatList.Contains($p.Name)) { $label = $script:BloatList[$p.Name] }
        else { foreach ($k in $script:BloatWild.Keys) { if ($p.Name -like $k) { $label = $script:BloatWild[$k]; break } } }
        if ($label -and ($p.NonRemovable -ne $true) -and -not ($res | Where-Object { $_.Name -eq $p.Name })) {
            [void]$res.Add([pscustomobject]@{ Name = $p.Name; Label = $label })
        }
    }
    return , $res.ToArray()
}

function Get-HealthScore($d) {
    $s = 100; $why = New-Object System.Collections.ArrayList
    if ($d.DiskKind -eq 'HDD') { $s -= 30; [void]$why.Add('하드디스크(HDD) 사용 — 느린 가장 큰 원인') }
    elseif ($d.DiskKind -eq '확인 불가') { $s -= 10; [void]$why.Add('저장장치 종류 확인 불가') }
    if ($d.RamTotalGB -lt 3.5) { $s -= 25; [void]$why.Add('메모리 4GB 미만 — 크롬 탭 몇 개에도 버벅임') }
    elseif ($d.RamTotalGB -lt 7.5) { $s -= 12; [void]$why.Add('메모리 8GB 미만') }
    if ($d.StartupOn -gt 10) { $s -= 10; [void]$why.Add("시작프로그램 $($d.StartupOn)개 — 너무 많음") }
    elseif ($d.StartupOn -gt 5) { $s -= 5; [void]$why.Add("시작프로그램 $($d.StartupOn)개") }
    if ($d.DiskFreePct -lt 10) { $s -= 10; [void]$why.Add('C드라이브 여유 공간 10% 미만') }
    elseif ($d.DiskFreePct -lt 20) { $s -= 5; [void]$why.Add('C드라이브 여유 공간 20% 미만') }
    if ($d.BootSec -and $d.BootSec -gt 90) { $s -= 10; [void]$why.Add("부팅 $($d.BootSec)초 — 매우 느림") }
    elseif ($d.BootSec -and $d.BootSec -gt 45) { $s -= 5; [void]$why.Add("부팅 $($d.BootSec)초") }
    if ($d.TempBytes -gt 1GB) { $s -= 5; [void]$why.Add('임시파일 1GB 이상 쌓임') }
    if ($d.RamUsedPct -gt 80) { $s -= 5; [void]$why.Add("메모리 사용률 $($d.RamUsedPct)%") }
    if ($s -lt 0) { $s = 0 }
    $grade = if ($s -ge 80) { '쌩쌩' } elseif ($s -ge 55) { '보통' } else { '똥컴' }
    return @{ Score = $s; Grade = $grade; Why = $why.ToArray() }
}

function Get-Diagnosis {
    $d = [ordered]@{}
    $os = Get-CimInstance Win32_OperatingSystem
    $cs = Get-CimInstance Win32_ComputerSystem
    $cpu = @(Get-CimInstance Win32_Processor)[0]
    $d.Time = (Get-Date).ToString('yyyy-MM-dd HH:mm')
    $d.ComputerName = $env:COMPUTERNAME
    $d.OS = $os.Caption; $d.OSBuild = $os.BuildNumber
    $d.IsWin10 = [bool]($os.Caption -match 'Windows 10')
    $d.Is64 = [Environment]::Is64BitOperatingSystem
    $d.Manufacturer = [string]$cs.Manufacturer
    $d.Model = ('{0} {1}' -f $cs.Manufacturer, $cs.Model).Trim()
    $chassis = @((Get-CimInstance Win32_SystemEnclosure -ErrorAction SilentlyContinue).ChassisTypes)
    $d.IsLaptop = [bool](($cs.PCSystemType -eq 2) -or (@($chassis | Where-Object { $_ -in 8, 9, 10, 11, 12, 14, 18, 21, 30, 31, 32 }).Count -gt 0))
    $d.CPU = ($cpu.Name -replace '\s+', ' ').Trim()
    $d.Cores = [int]$cpu.NumberOfCores; $d.Threads = [int]$cpu.NumberOfLogicalProcessors

    $totalKB = [double]$os.TotalVisibleMemorySize; $freeKB = [double]$os.FreePhysicalMemory
    $d.RamTotalGB = [math]::Round($totalKB / 1MB, 1)
    $d.RamUsedPct = [int][math]::Round((($totalKB - $freeKB) / $totalKB) * 100)
    $mods = @(Get-CimInstance Win32_PhysicalMemory -ErrorAction SilentlyContinue)
    $slots = (Get-CimInstance Win32_PhysicalMemoryArray -ErrorAction SilentlyContinue | Measure-Object -Property MemoryDevices -Sum).Sum
    $d.RamModules = $mods.Count
    $d.RamSlots = if ($slots) { [int]$slots } else { 0 }
    $d.RamType = Get-RamType $mods
    $ff = @($mods | ForEach-Object { [int]$_.FormFactor })
    $d.RamForm = if ($ff -contains 12) { 'SODIMM(노트북용)' } elseif ($ff -contains 8) { 'DIMM(데스크톱용)' } elseif ($d.IsLaptop) { 'SODIMM(노트북용, 추정)' } else { 'DIMM(데스크톱용, 추정)' }
    $sp = ($mods | Measure-Object -Property Speed -Maximum).Maximum
    $d.RamSpeed = if ($sp) { [int]$sp } else { 0 }
    $d.RamSoldered = [bool]($d.RamType -match 'LPDDR')
    $d.RamModuleGB = @($mods | ForEach-Object { [math]::Round([double]$_.Capacity / 1GB) })

    $sys = $env:SystemDrive
    $ld = Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='$sys'"
    $d.DiskSizeGB = [math]::Round($ld.Size / 1GB)
    $d.DiskFreeGB = [math]::Round($ld.FreeSpace / 1GB, 1)
    $d.DiskFreePct = [int][math]::Round($ld.FreeSpace / $ld.Size * 100)
    $d.DiskKind = '확인 불가'; $d.DiskBus = ''; $d.DiskName = ''
    try {
        $part = Get-Partition -DriveLetter $sys.TrimEnd(':') -ErrorAction Stop
        $pd = Get-CimInstance -Namespace 'root\Microsoft\Windows\Storage' -ClassName MSFT_PhysicalDisk -ErrorAction Stop |
            Where-Object { [string]$_.DeviceId -eq [string]$part.DiskNumber } | Select-Object -First 1
        if ($pd) {
            $d.DiskName = [string]$pd.FriendlyName
            $bus = @{ 7 = 'USB'; 8 = 'RAID'; 10 = 'SAS'; 11 = 'SATA'; 17 = 'NVMe' }
            if ($bus.ContainsKey([int]$pd.BusType)) { $d.DiskBus = $bus[[int]$pd.BusType] }
            switch ([int]$pd.MediaType) {
                3 { $d.DiskKind = 'HDD' }
                4 { $d.DiskKind = 'SSD' }
                5 { $d.DiskKind = 'SSD' }
                default {
                    if ($d.DiskBus -eq 'NVMe' -or $d.DiskName -match 'SSD|NVMe|Solid') { $d.DiskKind = 'SSD' }
                    elseif ([int64]$pd.SpindleSpeed -gt 0 -and [int64]$pd.SpindleSpeed -lt 100000) { $d.DiskKind = 'HDD' }
                }
            }
        }
    } catch {}

    $boot = Get-BootInfo
    $d.BootSec = if ($boot) { $boot.Seconds } else { $null }
    $d.BootWhen = if ($boot) { $boot.When.ToString('yyyy-MM-dd HH:mm') } else { '' }
    $items = Get-StartupItems
    $script:StartupItems = $items
    $d.StartupTotal = @($items).Count
    $d.StartupOn = @($items | Where-Object { $_.Enabled }).Count
    $d.TempBytes = [int64]((Get-FolderSize $env:TEMP) + (Get-FolderSize (Join-Path $env:windir 'Temp')))
    $d.Processes = @(Get-Process).Count
    $d.Bloat = Get-BloatApps
    $d.BloatCount = @($d.Bloat).Count
    $pp = Get-PowerPlan
    $d.PowerPlan = $pp.Name; $d.PowerGuid = $pp.Guid
    $h = Get-HealthScore $d
    $d.Score = $h.Score; $d.Grade = $h.Grade; $d.Why = $h.Why
    return $d
}

function Get-DiagRows($d) {
    # 각 행: 항목, 결과, 판정, 수준(red/orange/green/'')
    $rows = New-Object System.Collections.ArrayList
    $kind = if ($d.IsLaptop) { '노트북' } else { '데스크톱' }
    [void]$rows.Add(@('컴퓨터', "$($d.Model) ($kind)", '', ''))
    if ($d.IsWin10) { [void]$rows.Add(@('운영체제', "$($d.OS) (빌드 $($d.OSBuild))", 'Windows 10 지원 종료', 'red')) }
    else { [void]$rows.Add(@('운영체제', "$($d.OS) (빌드 $($d.OSBuild))", '정상', 'green')) }
    [void]$rows.Add(@('CPU', "$($d.CPU) ($($d.Cores)코어/$($d.Threads)스레드)", '', ''))
    $slotTxt = if ($d.RamSlots -gt 0) { "슬롯 $($d.RamModules)/$($d.RamSlots) 사용" } else { "모듈 $($d.RamModules)개" }
    $ramTxt = "$($d.RamTotalGB) GB · $($d.RamType) · $($d.RamForm)" + $(if ($d.RamSpeed) { " · $($d.RamSpeed)MHz" } else { '' }) + " · $slotTxt"
    if ($d.RamTotalGB -lt 3.5) { [void]$rows.Add(@('메모리', $ramTxt, '부족', 'red')) }
    elseif ($d.RamTotalGB -lt 7.5) { [void]$rows.Add(@('메모리', $ramTxt, '아쉬움', 'orange')) }
    else { [void]$rows.Add(@('메모리', $ramTxt, '충분', 'green')) }
    if ($d.RamUsedPct -gt 80) { [void]$rows.Add(@('메모리 사용률', "$($d.RamUsedPct)%", '높음', 'orange')) } else { [void]$rows.Add(@('메모리 사용률', "$($d.RamUsedPct)%", '정상', 'green')) }
    $diskTxt = "$($d.DiskKind) $($d.DiskBus) · $($d.DiskName)".Trim()
    switch ($d.DiskKind) {
        'HDD' { [void]$rows.Add(@('저장장치', $diskTxt, '교체 1순위', 'red')) }
        'SSD' { [void]$rows.Add(@('저장장치', $diskTxt, '좋음', 'green')) }
        default { [void]$rows.Add(@('저장장치', $diskTxt, '확인 불가', 'orange')) }
    }
    $freeTxt = "$($d.DiskFreeGB) GB 남음 / 전체 $($d.DiskSizeGB) GB ($($d.DiskFreePct)%)"
    if ($d.DiskFreePct -lt 10) { [void]$rows.Add(@('C드라이브 여유', $freeTxt, '부족', 'red')) }
    elseif ($d.DiskFreePct -lt 20) { [void]$rows.Add(@('C드라이브 여유', $freeTxt, '빠듯함', 'orange')) }
    else { [void]$rows.Add(@('C드라이브 여유', $freeTxt, '정상', 'green')) }
    if ($null -eq $d.BootSec) { [void]$rows.Add(@('부팅 시간', '측정 불가 (관리자 권한 필요)', '', '')) }
    elseif ($d.BootSec -gt 90) { [void]$rows.Add(@('부팅 시간', "$($d.BootSec)초 (측정: $($d.BootWhen))", '매우 느림', 'red')) }
    elseif ($d.BootSec -gt 45) { [void]$rows.Add(@('부팅 시간', "$($d.BootSec)초 (측정: $($d.BootWhen))", '느림', 'orange')) }
    else { [void]$rows.Add(@('부팅 시간', "$($d.BootSec)초 (측정: $($d.BootWhen))", '정상', 'green')) }
    $stTxt = "켜짐 $($d.StartupOn)개 / 전체 $($d.StartupTotal)개"
    if ($d.StartupOn -gt 10) { [void]$rows.Add(@('시작프로그램', $stTxt, '너무 많음', 'red')) }
    elseif ($d.StartupOn -gt 5) { [void]$rows.Add(@('시작프로그램', $stTxt, '정리 권장', 'orange')) }
    else { [void]$rows.Add(@('시작프로그램', $stTxt, '정상', 'green')) }
    if ($d.TempBytes -gt 1GB) { [void]$rows.Add(@('임시파일', (Format-Size $d.TempBytes), '청소 권장', 'orange')) } else { [void]$rows.Add(@('임시파일', (Format-Size $d.TempBytes), '정상', 'green')) }
    if ($d.BloatCount -gt 0) { [void]$rows.Add(@('불필요한 기본 앱', "$($d.BloatCount)개", '제거 가능', 'orange')) } else { [void]$rows.Add(@('불필요한 기본 앱', '없음', '정상', 'green')) }
    [void]$rows.Add(@('실행 중 프로세스', "$($d.Processes)개", '', ''))
    [void]$rows.Add(@('전원 모드', $d.PowerPlan, '', ''))
    return , $rows.ToArray()
}

# =====================================================================
#  처방전
# =====================================================================
function Get-BootMenuKey([string]$maker) {
    switch -Regex ($maker) {
        'Samsung' { return 'F10 (안 되면 ESC)' }
        'LG' { return 'F10' }
        'HP|Hewlett' { return 'F9 (또는 ESC 후 F9)' }
        'Dell' { return 'F12' }
        'Lenovo' { return 'F12 (일부 모델 Fn+F12)' }
        'ASUS' { return 'ESC 또는 F8' }
        'Acer' { return 'F12' }
        'MSI|Micro-Star' { return 'F11' }
        'Gigabyte' { return 'F12' }
        'ASRock' { return 'F11' }
        default { return 'F12 / F11 / F10 / ESC 중 하나 (제조사마다 다름)' }
    }
}

function Build-Prescription($d, $use, [int]$budget, [string]$dataOnly) {
    $A = New-Object System.Collections.ArrayList
    $B = New-Object System.Collections.ArrayList
    $Cx = New-Object System.Collections.ArrayList

    # ---------- A. 0원 청소 ----------
    $offCnt = @($script:StartupItems | Where-Object { $_.Enabled -and $_.Category -eq 'off' }).Count
    [void]$A.Add("시작프로그램: 켜짐 $($d.StartupOn)개 중 끄기 추천 $offCnt개 (나머지도 직접 골라 끌 수 있음, 보안·드라이버 프로그램은 '유지 권장' 표시)")
    [void]$A.Add("임시파일 청소: 약 $(Format-Size $d.TempBytes) 확보 예상 + 휴지통 비우기")
    if ($d.BloatCount -gt 0) { [void]$A.Add("불필요한 기본 앱 $($d.BloatCount)개 제거 (필요하면 Microsoft Store에서 다시 설치 가능)") }
    if ($d.IsLaptop) { [void]$A.Add('전원 모드: 노트북이라 배터리를 위해 그대로 둡니다 (원하면 고성능 체크)') }
    else { [void]$A.Add("전원 모드: '$($d.PowerPlan)' → '고성능'") }
    [void]$A.Add("시각 효과: 창 애니메이션·그림자 끄기 ('성능 우선', 다시 로그인하면 적용)")
    if ($d.DiskKind -eq 'SSD') { [void]$A.Add('드라이브 최적화: SSD TRIM 실행 (몇 분)') } else { [void]$A.Add('드라이브 최적화: 하드디스크 조각 모음 (30분~수 시간, 별도 창)') }
    if ($d.DiskFreePct -lt 15) { [void]$A.Add("주의: C드라이브 여유가 $($d.DiskFreePct)%입니다. 다운로드 폴더의 큰 파일·동영상을 USB로 옮기세요.") }
    [void]$A.Add('안전장치: 실행 직전 Windows 복원지점을 자동으로 만들고, [되돌리기] 버튼으로 설정을 원래대로 돌릴 수 있습니다.')

    # ---------- B. 부품 교체 ----------
    $needSsd = ($d.DiskKind -eq 'HDD')
    $needRam = ($d.RamTotalGB -lt 7.5) -and (-not $d.RamSoldered)
    $ssdSpec = if ($d.IsLaptop) { '2.5인치 SATA SSD (기존 하드디스크 자리에 그대로 교체)' } else { '2.5인치 SATA SSD + 3.5인치 변환 브래킷 (메인보드에 M.2 슬롯이 있으면 M.2도 가능)' }
    $ssdMove = if ($d.IsLaptop) { 'SATA-USB 변환 케이블(약 1만원)로 연결 후, SSD 제조사 무료 복제 프로그램(예: 삼성 Magician의 Data Migration)으로 윈도우를 그대로 옮깁니다.' } else { '새 SSD를 추가로 연결한 뒤, SSD 제조사 무료 복제 프로그램(예: 삼성 Magician의 Data Migration)으로 윈도우를 그대로 옮깁니다.' }
    $free = $d.RamSlots - $d.RamModules
    $ramSpec = "$($d.RamType -replace '\(추정\)','') $($d.RamForm -replace '\(.*\)','') 8GB" + $(if ($d.RamSpeed) { " ($($d.RamSpeed)MHz 이상)" } else { '' })
    $ramHow = if ($free -gt 0) { "빈 슬롯 $free개 → 같은 규격 8GB 1개 추가 (총 $([math]::Round($d.RamTotalGB + 8))GB)" } elseif ($d.RamSlots -gt 0) { '빈 슬롯 없음 → 기존 메모리를 8GB 2개(총 16GB) 또는 8GB 1개로 교체' } else { '슬롯 수 확인 불가 → 뚜껑을 열어 빈 슬롯 확인' }

    if (-not $needSsd -and -not $needRam) {
        [void]$B.Add('부품 교체가 꼭 필요하지 않습니다. 이미 SSD이고 메모리도 8GB 이상입니다. 처방 A만으로 충분합니다.')
        if ($d.RamSoldered) { [void]$B.Add('참고: 메모리가 메인보드에 붙어 있는(LPDDR) 모델이라 증설은 불가합니다.') }
    } else {
        if ($needSsd) {
            [void]$B.Add("[1순위] SSD 교체 — 체감 효과가 가장 큽니다 (부팅 1~2분 → 20~30초 수준).")
            [void]$B.Add("   규격: $ssdSpec")
            [void]$B.Add("   방법: $ssdMove")
        }
        if ($needRam) {
            $rank = if ($needSsd) { '[2순위]' } else { '[1순위]' }
            [void]$B.Add("$rank 메모리 증설 — 현재 $($d.RamTotalGB)GB")
            [void]$B.Add("   규격: $ramSpec")
            [void]$B.Add("   방법: $ramHow")
        }
        if ($d.RamSoldered -and $d.RamTotalGB -lt 7.5) { [void]$B.Add('참고: 메모리가 메인보드에 붙어 있는(LPDDR) 모델이라 증설은 불가합니다.') }
        [void]$B.Add('')
        switch ($budget) {
            0 {
                [void]$B.Add('예산 0원 → 이번에는 처방 A만 실행하세요. 부품 교체는 예산이 생기면 위 순서대로.')
                [void]$B.Add("   참고: $($Config.PriceSsdUsed) / $($Config.PriceRamUsed)")
            }
            5 {
                if ($needSsd) { [void]$B.Add("예산 5만원 → SSD만: $($Config.PriceSsdUsed) (중고 구매 시 '수명(TBW)·건강 상태 양호' 표기 확인)") }
                else { [void]$B.Add("예산 5만원 → 메모리만: $($Config.PriceRamUsed)") }
            }
            default {
                if ($needSsd -and $needRam) { [void]$B.Add("예산 10만원 → SSD + 메모리: $($Config.PriceSsdUsed) + $($Config.PriceRamUsed)") }
                elseif ($needSsd) { [void]$B.Add("예산 10만원 → 신품 SSD: $($Config.PriceSsdNew)") }
                else { [void]$B.Add("예산 10만원 → 신품 메모리: $($Config.PriceRamNew)") }
            }
        }
        [void]$B.Add("   * $($Config.PriceNote)")
    }

    # ---------- C. OS 전환 ----------
    $canFlex = $d.Is64 -and ($d.RamTotalGB -ge 3.5)
    $cRec = $false
    if ($use.Bank -or $use.Doc) {
        [void]$Cx.Add('비추천 — 윈도우를 유지하세요.')
        if ($use.Bank) { [void]$Cx.Add('인터넷등기소·은행·홈택스 보안프로그램은 ChromeOS Flex·리눅스에서 설치되지 않습니다.') }
        if ($use.Doc) { [void]$Cx.Add('한글(HWP) 프로그램은 윈도우 전용입니다. (웹용 한컴독스는 가능하지만 기능이 제한적)') }
        [void]$Cx.Add('→ 처방 A + B(SSD 교체)가 정답입니다.')
    } elseif ($canFlex) {
        $cRec = $true
        [void]$Cx.Add('추천 — 웹·유튜브만 쓰신다면 ChromeOS Flex(구글 무료 OS)가 가장 효과가 큽니다.')
        if ($d.IsWin10) { [void]$Cx.Add('특히 이 PC는 Windows 10이라 보안 업데이트가 끊겨 있어 전환 이점이 더 큽니다.') }
        [void]$Cx.Add('주의 ① 설치하면 저장장치의 모든 자료가 지워집니다 → 반드시 백업')
        [void]$Cx.Add('주의 ② 안드로이드 앱(카카오톡 PC 등 일부)·윈도우 프로그램은 실행되지 않습니다 (웹 버전은 사용 가능)')
        [void]$Cx.Add("주의 ③ USB 메모리 8GB 이상 필요, 이 PC의 부팅 메뉴 키: $(Get-BootMenuKey $d.Manufacturer)")
        [void]$Cx.Add('대안: Linux Mint (윈도우와 비슷한 화면, 무료) — 리눅스용 프로그램을 더 쓰고 싶을 때')
        [void]$Cx.Add("→ [C. OS 전환 안내] 탭에서 백업 체크리스트를 모두 확인하면 설치 안내가 열립니다.")
    } else {
        [void]$Cx.Add('불가 — ChromeOS Flex 최소 사양(64비트 CPU, 메모리 4GB)에 못 미칩니다. Linux Mint(가벼운 Xfce 판)를 고려하거나 처방 A·B를 진행하세요.')
    }
    if ($dataOnly -eq 'yes') { [void]$Cx.Add('※ 중요한 자료가 이 컴퓨터에만 있다고 하셨습니다. 어떤 처방이든 먼저 USB·클라우드에 백업하세요.') }

    # ---------- 요약 ----------
    $sum = "건강점수 $($d.Score)점 ($($d.Grade))."
    if ($needSsd) { $sum += ' 하드디스크가 가장 큰 원인입니다.' }
    elseif ($needRam) { $sum += ' 메모리가 부족합니다.' }
    else { $sum += ' 하드웨어는 쓸 만합니다. 청소로 충분합니다.' }
    if ($cRec) { $sum += ' 웹 전용이면 ChromeOS Flex 전환도 좋은 선택입니다.' }

    return [ordered]@{ Summary = $sum; A = $A.ToArray(); B = $B.ToArray(); C = $Cx.ToArray(); CRecommended = $cRec }
}

# =====================================================================
#  처방 A 실행 (안전장치 포함)
# =====================================================================
function New-SafeRestorePoint {
    $k = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\SystemRestore'
    $old = $null
    try {
        Enable-ComputerRestore -Drive "$env:SystemDrive\" -ErrorAction SilentlyContinue
        $old = (Get-ItemProperty -Path $k -Name SystemRestorePointCreationFrequency -ErrorAction SilentlyContinue).SystemRestorePointCreationFrequency
        New-ItemProperty -Path $k -Name SystemRestorePointCreationFrequency -Value 0 -PropertyType DWord -Force | Out-Null
        $desc = '똥컴닥터 처방A 실행 전 ' + (Get-Date -Format 'MMddHHmm')
        Checkpoint-Computer -Description $desc -RestorePointType MODIFY_SETTINGS -ErrorAction Stop
        $ok = @(Get-ComputerRestorePoint -ErrorAction SilentlyContinue | Where-Object { $_.Description -eq $desc }).Count -gt 0
        return $ok
    } catch {
        return $false
    } finally {
        if ($null -ne $old) { Set-ItemProperty -Path $k -Name SystemRestorePointCreationFrequency -Value $old -ErrorAction SilentlyContinue }
        else { Remove-ItemProperty -Path $k -Name SystemRestorePointCreationFrequency -ErrorAction SilentlyContinue }
    }
}

function Set-StartupApproved($item, [bool]$enabled) {
    if (-not (Test-Path $item.ApprPath)) { New-Item -Path $item.ApprPath -Force | Out-Null }
    $b = New-Object byte[] 12
    if ($enabled) { $b[0] = 2 } else { $b[0] = 3 }
    New-ItemProperty -Path $item.ApprPath -Name $item.Name -PropertyType Binary -Value $b -Force | Out-Null
}

function Clear-TempFiles {
    $freed = [int64]0
    foreach ($p in @($env:TEMP, (Join-Path $env:windir 'Temp'))) {
        if (-not (Test-Path -LiteralPath $p)) { continue }
        $before = Get-FolderSize $p
        Get-ChildItem -LiteralPath $p -Force -ErrorAction SilentlyContinue | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
        $freed += ($before - (Get-FolderSize $p))
    }
    return $freed
}

function Invoke-PrescriptionA {
    $selStartup = @()
    for ($i = 0; $i -lt $script:clbStartup.Items.Count; $i++) {
        if ($script:clbStartup.GetItemChecked($i)) { $selStartup += $script:StartupView[$i] }
    }
    $selBloat = @()
    for ($i = 0; $i -lt $script:clbBloat.Items.Count; $i++) {
        if ($script:clbBloat.GetItemChecked($i)) { $selBloat += $script:BloatView[$i] }
    }
    $settingsWanted = ($selStartup.Count -gt 0) -or ($selBloat.Count -gt 0) -or $script:chkPower.Checked -or $script:chkVisual.Checked
    $msg = "다음을 실행합니다.`n`n" +
    "• 시작프로그램 끄기: $($selStartup.Count)개`n" +
    "• 기본 앱 제거: $($selBloat.Count)개`n" +
    "• 임시파일 청소: $(if($script:chkTemp.Checked){'예'}else{'아니오'})   • 휴지통 비우기: $(if($script:chkRecycle.Checked){'예'}else{'아니오'})`n" +
    "• 전원 고성능: $(if($script:chkPower.Checked){'예'}else{'아니오'})   • 시각효과 성능우선: $(if($script:chkVisual.Checked){'예'}else{'아니오'})`n" +
    "• 드라이브 최적화: $(if($script:chkDefrag.Checked){'예'}else{'아니오'})`n`n" +
    "실행 전에 복원지점을 자동으로 만듭니다(1~2분). 계속할까요?"
    if ([System.Windows.Forms.MessageBox]::Show($msg, '처방 A 실행', 'YesNo', 'Question') -ne 'Yes') { return }

    $script:btnApply.Enabled = $false
    $filesOnly = $false
    if ($settingsWanted) {
        $rpOk = $false
        if ($script:IsAdmin) {
            Write-Log '복원지점 만드는 중... (1~2분 걸릴 수 있습니다)'
            Set-Status '복원지점 만드는 중...'
            $rpOk = New-SafeRestorePoint
        }
        if ($rpOk) { Write-Log '복원지점 생성 완료' }
        else {
            Write-Log '복원지점 생성 실패'
            $r = [System.Windows.Forms.MessageBox]::Show("복원지점을 만들지 못했습니다.`n(관리자 권한이 없거나 '시스템 보호'가 꺼져 있을 수 있습니다)`n`n안전을 위해 설정 변경(시작프로그램·앱 제거·전원·시각효과)은 건너뛰고`n파일 청소만 진행할까요?", '안전장치', 'YesNo', 'Warning')
            if ($r -ne 'Yes') { $script:btnApply.Enabled = $true; Set-Status '취소했습니다.'; return }
            $filesOnly = $true
        }
    }

    $undo = [ordered]@{ Time = (Get-Date).ToString('yyyy-MM-dd HH:mm'); Startup = @(); PowerGuid = ''; VisualFX = $null; VisualFXChanged = $false }

    if (-not $filesOnly) {
        foreach ($it in $selStartup) {
            try {
                $prev = $null
                try { $prev = (Get-Item -LiteralPath $it.ApprPath -ErrorAction Stop).GetValue($it.Name) } catch {}
                Set-StartupApproved $it $false
                $undo.Startup += [ordered]@{ Name = $it.Name; ApprPath = $it.ApprPath; Prev = $(if ($prev -is [byte[]]) { [Convert]::ToBase64String($prev) } else { '' }) }
                Write-Log "시작프로그램 끔: $($it.Name)"
            } catch { Write-Log "시작프로그램 끄기 실패: $($it.Name) — $($_.Exception.Message)" }
        }
        foreach ($b in $selBloat) {
            try {
                Get-AppxPackage -Name $b.Name -ErrorAction Stop | Remove-AppxPackage -ErrorAction Stop
                Write-Log "앱 제거: $($b.Label)"
            } catch { Write-Log "앱 제거 실패: $($b.Label) — $($_.Exception.Message)" }
        }
        if ($script:chkPower.Checked) {
            $pp = Get-PowerPlan
            $undo.PowerGuid = $pp.Guid
            powercfg /setactive SCHEME_MIN 2>$null | Out-Null
            Write-Log "전원 모드: '$($pp.Name)' → 고성능"
        }
        if ($script:chkVisual.Checked) {
            $vk = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects'
            if (-not (Test-Path $vk)) { New-Item -Path $vk -Force | Out-Null }
            $undo.VisualFX = (Get-ItemProperty -Path $vk -Name VisualFXSetting -ErrorAction SilentlyContinue).VisualFXSetting
            $undo.VisualFXChanged = $true
            New-ItemProperty -Path $vk -Name VisualFXSetting -Value 2 -PropertyType DWord -Force | Out-Null
            Write-Log '시각 효과: 성능 우선 (다시 로그인하면 적용)'
        }
        if ($settingsWanted) { $undo | ConvertTo-Json -Depth 5 | Set-Content -Path $script:UndoFile -Encoding UTF8 }
    }

    if ($script:chkTemp.Checked) {
        Set-Status '임시파일 청소 중...'
        $f = Clear-TempFiles
        Write-Log "임시파일 청소: $(Format-Size $f) 확보"
    }
    if ($script:chkRecycle.Checked) {
        try { Clear-RecycleBin -Force -ErrorAction Stop; Write-Log '휴지통 비움' } catch { Write-Log '휴지통: 이미 비어 있음' }
    }
    if ($script:chkDefrag.Checked) {
        try {
            Start-Process -FilePath 'defrag.exe' -ArgumentList @($env:SystemDrive, '/O', '/U', '/V') -ErrorAction Stop
            Write-Log '드라이브 최적화 시작 (별도 창에서 진행, 끝날 때까지 PC를 끄지 마세요)'
        } catch { Write-Log '드라이브 최적화 실행 실패 (관리자 권한 필요)' }
    }

    Write-Log '처방 A 완료 — 다시 진단합니다.'
    Set-Status '다시 진단 중...'
    $script:Diag = Get-Diagnosis
    Save-Baseline -Applied
    Show-Diagnosis
    Fill-ActionLists
    Fill-Compare
    $script:btnApply.Enabled = $true
    $script:tabs.SelectedTab = $script:tab5
    [System.Windows.Forms.MessageBox]::Show("처방 A를 마쳤습니다.`n`n컴퓨터를 한 번 다시 시작한 뒤 똥컴닥터를 다시 실행하면`n부팅 시간까지 전후 비교가 됩니다.", '완료', 'OK', 'Information') | Out-Null
    Set-Status '처방 A 완료'
}

function Invoke-Undo {
    if (-not (Test-Path $script:UndoFile)) { [System.Windows.Forms.MessageBox]::Show('되돌릴 기록이 없습니다.', '되돌리기') | Out-Null; return }
    $u = Get-Content -Path $script:UndoFile -Raw -Encoding UTF8 | ConvertFrom-Json
    $r = [System.Windows.Forms.MessageBox]::Show("$($u.Time)에 바꾼 설정(시작프로그램 $(@($u.Startup).Count)개, 전원, 시각효과)을 원래대로 돌립니다.`n(삭제한 앱은 Microsoft Store에서 다시 설치하세요)`n`n계속할까요?", '되돌리기', 'YesNo', 'Question')
    if ($r -ne 'Yes') { return }
    foreach ($s in @($u.Startup)) {
        try {
            if ($s.Prev) { New-ItemProperty -Path $s.ApprPath -Name $s.Name -PropertyType Binary -Value ([Convert]::FromBase64String($s.Prev)) -Force | Out-Null }
            else { Remove-ItemProperty -Path $s.ApprPath -Name $s.Name -ErrorAction Stop }
            Write-Log "시작프로그램 복구: $($s.Name)"
        } catch { Write-Log "복구 실패: $($s.Name)" }
    }
    if ($u.PowerGuid) { powercfg /setactive $u.PowerGuid 2>$null | Out-Null; Write-Log '전원 모드 복구' }
    if ($u.VisualFXChanged) {
        $vk = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects'
        if ($null -ne $u.VisualFX) { Set-ItemProperty -Path $vk -Name VisualFXSetting -Value ([int]$u.VisualFX) } else { Remove-ItemProperty -Path $vk -Name VisualFXSetting -ErrorAction SilentlyContinue }
        Write-Log '시각 효과 복구'
    }
    Rename-Item -Path $script:UndoFile -NewName ('undo_done_' + (Get-Date -Format 'yyyyMMddHHmm') + '.json') -ErrorAction SilentlyContinue
    Write-Log '되돌리기 완료. 더 확실히 하려면 Windows [시스템 복원]에서 "똥컴닥터" 복원지점을 고르세요.'
    $script:Diag = Get-Diagnosis; Show-Diagnosis; Fill-ActionLists; Fill-Compare
}

# =====================================================================
#  기준(처음 진단) 저장 / 비교
# =====================================================================
function Save-Baseline([switch]$Force, [switch]$Applied) {
    if ($Applied -and $script:Baseline) {
        $script:Baseline.AppliedAt = (Get-Date).ToString('yyyy-MM-dd HH:mm')
        $script:Baseline | ConvertTo-Json -Depth 3 | Set-Content -Path $script:BaselineFile -Encoding UTF8
        return
    }
    if ((Test-Path $script:BaselineFile) -and -not $Force) { return }
    $d = $script:Diag
    $b = [ordered]@{
        Time = $d.Time; Score = $d.Score; Grade = $d.Grade; BootSec = $d.BootSec; BootWhen = $d.BootWhen
        StartupOn = $d.StartupOn; RamUsedPct = $d.RamUsedPct; DiskFreeGB = $d.DiskFreeGB; TempBytes = $d.TempBytes
        Processes = $d.Processes; BloatCount = $d.BloatCount; PowerPlan = $d.PowerPlan; AppliedAt = ''
    }
    $b | ConvertTo-Json -Depth 3 | Set-Content -Path $script:BaselineFile -Encoding UTF8
    $script:Baseline = Get-Content -Path $script:BaselineFile -Raw -Encoding UTF8 | ConvertFrom-Json
}

function Load-Baseline {
    if (Test-Path $script:BaselineFile) {
        try { $script:Baseline = Get-Content -Path $script:BaselineFile -Raw -Encoding UTF8 | ConvertFrom-Json } catch { $script:Baseline = $null }
    }
}

function Get-CompareRows {
    $b = $script:Baseline; $d = $script:Diag
    $rows = New-Object System.Collections.ArrayList
    if (-not $b -or -not $d) { return , $rows.ToArray() }
    function _delta($before, $after, [string]$unit, [bool]$lowerBetter) {
        if ($null -eq $before -or $null -eq $after -or "$before" -eq '' -or "$after" -eq '') { return '—' }
        $diff = [double]$after - [double]$before
        if ([math]::Abs($diff) -lt 0.05) { return '변화 없음' }
        $better = if ($lowerBetter) { $diff -lt 0 } else { $diff -gt 0 }
        $sign = if ($diff -gt 0) { '+' } else { '' }
        $tag = if ($better) { '개선' } else { '악화' }
        return ('{0}{1:N1}{2} ({3})' -f $sign, $diff, $unit, $tag)
    }
    $bootB = if ($null -ne $b.BootSec -and "$($b.BootSec)" -ne '') { "$($b.BootSec)초" } else { '측정 불가' }
    $bootA = if ($null -ne $d.BootSec) { "$($d.BootSec)초" } else { '측정 불가' }
    if ($b.BootWhen -and $d.BootWhen -and $b.BootWhen -eq $d.BootWhen) { $bootA = "$bootA (재부팅 후 측정)" }
    [void]$rows.Add(@('건강점수', "$($b.Score)점 ($($b.Grade))", "$($d.Score)점 ($($d.Grade))", (_delta $b.Score $d.Score '점' $false)))
    [void]$rows.Add(@('부팅 시간', $bootB, $bootA, $(if ($b.BootWhen -eq $d.BootWhen) { '재부팅 후 다시 실행' } else { _delta $b.BootSec $d.BootSec '초' $true })))
    [void]$rows.Add(@('켜진 시작프로그램', "$($b.StartupOn)개", "$($d.StartupOn)개", (_delta $b.StartupOn $d.StartupOn '개' $true)))
    [void]$rows.Add(@('메모리 사용률', "$($b.RamUsedPct)%", "$($d.RamUsedPct)%", (_delta $b.RamUsedPct $d.RamUsedPct '%p' $true)))
    [void]$rows.Add(@('C드라이브 여유', "$($b.DiskFreeGB) GB", "$($d.DiskFreeGB) GB", (_delta $b.DiskFreeGB $d.DiskFreeGB ' GB' $false)))
    [void]$rows.Add(@('임시파일', (Format-Size $b.TempBytes), (Format-Size $d.TempBytes), (_delta ([double]$b.TempBytes / 1MB) ([double]$d.TempBytes / 1MB) ' MB' $true)))
    [void]$rows.Add(@('실행 중 프로세스', "$($b.Processes)개", "$($d.Processes)개", (_delta $b.Processes $d.Processes '개' $true)))
    [void]$rows.Add(@('불필요한 기본 앱', "$($b.BloatCount)개", "$($d.BloatCount)개", (_delta $b.BloatCount $d.BloatCount '개' $true)))
    [void]$rows.Add(@('전원 모드', [string]$b.PowerPlan, [string]$d.PowerPlan, ''))
    return , $rows.ToArray()
}

# =====================================================================
#  처방 리포트 (HTML → 브라우저에서 인쇄/PDF 저장)
# =====================================================================
function Save-Report {
    if (-not $script:Diag) { [System.Windows.Forms.MessageBox]::Show('먼저 진단을 실행하세요.') | Out-Null; return }
    if (-not $script:Rx) { Make-Rx }
    $d = $script:Diag; $rx = $script:Rx
    $diagHtml = ''
    foreach ($r in (Get-DiagRows $d)) {
        $cls = $r[3]
        $diagHtml += "<tr><th>$(HtmlEnc $r[0])</th><td>$(HtmlEnc $r[1])</td><td class='v $cls'>$(HtmlEnc $r[2])</td></tr>`n"
    }
    $li = { param($arr) ($arr | Where-Object { $_ -ne '' } | ForEach-Object { "<li>$(HtmlEnc ($_.Trim()))</li>" }) -join "`n" }
    $cmpHtml = ''
    $cmp = Get-CompareRows
    if ($cmp.Count -gt 0) {
        $cmpHtml = "<h2>전후 비교</h2><p class='note'>처음 진단 $(HtmlEnc $script:Baseline.Time) → 지금 $(HtmlEnc $d.Time)</p><table class='cmp'><tr><th>항목</th><th>처음</th><th>지금</th><th>변화</th></tr>"
        foreach ($c in $cmp) {
            $cls = if ($c[3] -match '개선') { 'green' } elseif ($c[3] -match '악화') { 'red' } else { '' }
            $cmpHtml += "<tr><td>$(HtmlEnc $c[0])</td><td>$(HtmlEnc $c[1])</td><td>$(HtmlEnc $c[2])</td><td class='$cls'>$(HtmlEnc $c[3])</td></tr>"
        }
        $cmpHtml += '</table>'
    }
    $logHtml = ''
    if ($script:ActionLog.Count -gt 0) {
        $logHtml = "<h2>실행 기록</h2><ul class='log'>" + (($script:ActionLog | ForEach-Object { "<li>$(HtmlEnc $_)</li>" }) -join '') + '</ul>'
    }
    $gradeCls = switch ($d.Grade) { '쌩쌩' { 'green' } '보통' { 'orange' } default { 'red' } }
    $useTxt = @()
    if ($script:chkUseWeb.Checked) { $useTxt += '웹·유튜브' }
    if ($script:chkUseDoc.Checked) { $useTxt += '한글·엑셀' }
    if ($script:chkUseBank.Checked) { $useTxt += '인터넷등기소·은행' }
    $budgetTxt = if ($script:rbB0.Checked) { '0원' } elseif ($script:rbB5.Checked) { '5만원' } else { '10만원' }

    $html = @"
<!DOCTYPE html>
<html lang="ko"><head><meta charset="utf-8"><title>똥컴 처방전 - $(HtmlEnc $d.ComputerName)</title>
<style>
 body{font-family:'Malgun Gothic','맑은 고딕',sans-serif;color:#23292B;max-width:820px;margin:24px auto;padding:0 20px;line-height:1.55}
 header{display:flex;justify-content:space-between;align-items:flex-end;border-bottom:4px solid #F77235;padding-bottom:10px}
 .brand{font-weight:800;font-size:15px;color:#23292B}.brand b{color:#F77235}
 h1{margin:6px 0 0;font-size:26px} h2{font-size:18px;margin:26px 0 8px;padding-left:10px;border-left:5px solid #F77235}
 .score{background:#FDEEE5;border:1px solid #F9B48F;border-radius:12px;padding:14px 18px;margin:18px 0;display:flex;gap:22px;align-items:center}
 .score .n{font-size:44px;font-weight:800}.score .g{font-size:20px;font-weight:700}
 table{width:100%;border-collapse:collapse;font-size:14px} th,td{border-bottom:1px solid #e5e5e5;padding:7px 8px;text-align:left;vertical-align:top}
 th{width:130px;color:#666;font-weight:600} .cmp th{width:auto;background:#f6f6f6}
 .v{width:110px;font-weight:700} .red{color:#C82828}.orange{color:#D66E00}.green{color:#1E873C}
 .rx{border:1px solid #e5e5e5;border-radius:10px;padding:10px 16px;margin:10px 0} .rx h3{margin:4px 0 6px;font-size:16px}
 .rx ul{margin:0;padding-left:20px} .note{color:#777;font-size:12.5px} .log{font-size:12.5px;color:#555}
 footer{margin-top:30px;border-top:1px solid #ddd;padding-top:12px;font-size:12.5px;color:#666}
 @media print{body{margin:0} .noprint{display:none}}
</style></head><body>
<header><div><div class="brand"><b>Land3 Lab</b> 랜드3 연구소</div><h1>똥컴 업그레이드 처방전</h1></div>
<div class="note">진단일 $(HtmlEnc $d.Time)<br>PC 이름 $(HtmlEnc $d.ComputerName)</div></header>
<p class="noprint note">※ 인쇄하거나 PDF로 저장하려면 Ctrl+P → '대상: PDF로 저장'을 고르세요.</p>
<div class="score"><div class="n $gradeCls">$($d.Score)<span style="font-size:18px">점</span></div>
<div><div class="g $gradeCls">$(HtmlEnc $d.Grade)</div><div>$(HtmlEnc $rx.Summary)</div>
<div class="note">주 용도: $(HtmlEnc ($useTxt -join ', ')) · 예산: $budgetTxt</div></div></div>
<h2>진단 결과</h2><table>$diagHtml</table>
<h2>처방전</h2>
<div class="rx"><h3>A. 0원 청소 (프로그램이 자동 실행)</h3><ul>$(& $li $rx.A)</ul></div>
<div class="rx"><h3>B. 부품 교체</h3><ul>$(& $li $rx.B)</ul></div>
<div class="rx"><h3>C. 운영체제 전환 (ChromeOS Flex / Linux Mint)</h3><ul>$(& $li $rx.C)</ul></div>
$cmpHtml
$logHtml
<footer><b>$(HtmlEnc $Config.Office)</b> · $(HtmlEnc $Config.Person)<br>$(HtmlEnc $Config.Address) · ☎ $(HtmlEnc $Config.Phone)<br>
<span class="note">본 처방전은 똥컴닥터 v$($Config.Version)의 자동 진단 결과로 참고용입니다. 부품 가격은 시세에 따라 달라집니다. 설정 변경 전 복원지점을 자동 생성하며, 운영체제 전환 시 모든 자료가 삭제되므로 반드시 백업하세요.</span></footer>
</body></html>
"@
    $desk = [Environment]::GetFolderPath('Desktop')
    $path = Join-Path $desk ('똥컴처방전_' + $d.ComputerName + '_' + (Get-Date -Format 'yyyyMMdd_HHmm') + '.html')
    [System.IO.File]::WriteAllText($path, $html, (New-Object System.Text.UTF8Encoding($true)))
    Start-Process $path
    Set-Status "리포트 저장: $path"
}

# =====================================================================
#  화면 (WinForms)
# =====================================================================
$fontBase = New-Object System.Drawing.Font('Malgun Gothic', 10)
$fontBold = New-Object System.Drawing.Font('Malgun Gothic', 10, [System.Drawing.FontStyle]::Bold)

function New-Btn([string]$text, [int]$x, [int]$y, [int]$w, [int]$h, [bool]$primary) {
    $b = New-Object System.Windows.Forms.Button
    $b.Text = $text; $b.Location = New-Object System.Drawing.Point($x, $y); $b.Size = New-Object System.Drawing.Size($w, $h)
    $b.FlatStyle = 'Flat'; $b.Font = $fontBold; $b.Cursor = 'Hand'
    if ($primary) { $b.BackColor = $C_BRAND; $b.ForeColor = [System.Drawing.Color]::White; $b.FlatAppearance.BorderSize = 0 }
    else { $b.BackColor = [System.Drawing.Color]::White; $b.ForeColor = $C_CHAR; $b.FlatAppearance.BorderColor = $C_BRAND }
    return $b
}
function New-Lbl([string]$text, [int]$x, [int]$y, [int]$w, [int]$h) {
    $l = New-Object System.Windows.Forms.Label
    $l.Text = $text; $l.Location = New-Object System.Drawing.Point($x, $y); $l.Size = New-Object System.Drawing.Size($w, $h)
    return $l
}
function New-Chk([string]$text, [int]$x, [int]$y, [int]$w, [bool]$checked) {
    $c = New-Object System.Windows.Forms.CheckBox
    $c.Text = $text; $c.Location = New-Object System.Drawing.Point($x, $y); $c.Size = New-Object System.Drawing.Size($w, 26); $c.Checked = $checked
    return $c
}
function New-LV([int]$x, [int]$y, [int]$w, [int]$h, $cols) {
    $lv = New-Object System.Windows.Forms.ListView
    $lv.Location = New-Object System.Drawing.Point($x, $y); $lv.Size = New-Object System.Drawing.Size($w, $h)
    $lv.View = 'Details'; $lv.FullRowSelect = $true; $lv.GridLines = $true; $lv.HeaderStyle = 'Nonclickable'
    foreach ($c in $cols) { [void]$lv.Columns.Add($c[0], $c[1]) }
    return $lv
}
function Add-LVRow($lv, $cols, [string]$level) {
    $it = New-Object System.Windows.Forms.ListViewItem([string]$cols[0])
    for ($i = 1; $i -lt $cols.Count; $i++) { [void]$it.SubItems.Add([string]$cols[$i]) }
    $it.UseItemStyleForSubItems = $false
    $color = switch ($level) { 'red' { $C_RED } 'orange' { $C_ORANGE } 'green' { $C_GREEN } default { $null } }
    if ($color -and $it.SubItems.Count -ge 3) { $it.SubItems[$it.SubItems.Count - 1].ForeColor = $color }
    [void]$lv.Items.Add($it)
}

$form = New-Object System.Windows.Forms.Form
$form.Text = "$($Config.AppName) v$($Config.Version) — 랜드3 연구소" + $(if (-not $script:IsAdmin) { '  [제한 모드: 관리자 권한 없음]' } else { '' })
$form.Size = New-Object System.Drawing.Size(900, 720)
$form.StartPosition = 'CenterScreen'; $form.Font = $fontBase; $form.BackColor = [System.Drawing.Color]::White
$form.FormBorderStyle = 'FixedSingle'; $form.MaximizeBox = $false

$header = New-Object System.Windows.Forms.Panel
$header.Dock = 'Top'; $header.Height = 62; $header.BackColor = $C_CHAR
$lblTitle = New-Lbl '똥컴닥터' 18 8 300 30
$lblTitle.Font = New-Object System.Drawing.Font('Malgun Gothic', 16, [System.Drawing.FontStyle]::Bold); $lblTitle.ForeColor = $C_BRAND
$lblSub = New-Lbl '아들이 쓰던 10년 전 컴퓨터도 쌩쌩하게 — 진단 → 처방 → 실행 → 전후 비교' 20 38 600 20
$lblSub.ForeColor = [System.Drawing.Color]::White
$lblBrand = New-Lbl 'Land3 Lab  랜드3 연구소' 650 20 220 24
$lblBrand.ForeColor = [System.Drawing.Color]::White; $lblBrand.Font = $fontBold; $lblBrand.TextAlign = 'MiddleRight'
$header.Controls.AddRange(@($lblTitle, $lblSub, $lblBrand))

$script:lblStatus = New-Object System.Windows.Forms.Label
$script:lblStatus.Dock = 'Bottom'; $script:lblStatus.Height = 26; $script:lblStatus.BackColor = [System.Drawing.Color]::FromArgb(245, 245, 245)
$script:lblStatus.TextAlign = 'MiddleLeft'; $script:lblStatus.Padding = New-Object System.Windows.Forms.Padding(10, 0, 0, 0)
$script:lblStatus.Text = $(if ($script:IsAdmin) { '준비됨 — [진단 시작]을 누르세요.' } else { '제한 모드: 관리자 권한이 없어 부팅시간 측정·설정 변경이 제한됩니다. 실행.bat을 다시 열고 [예]를 누르세요.' })

$script:tabs = New-Object System.Windows.Forms.TabControl
$script:tabs.Dock = 'Fill'; $script:tabs.Padding = New-Object System.Drawing.Point(14, 6)
$tab1 = New-Object System.Windows.Forms.TabPage; $tab1.Text = '1. 진단'
$tab2 = New-Object System.Windows.Forms.TabPage; $tab2.Text = '2. 질문 3개'
$tab3 = New-Object System.Windows.Forms.TabPage; $tab3.Text = '3. 처방전'
$tab4 = New-Object System.Windows.Forms.TabPage; $tab4.Text = '4. 처방 A 실행'
$script:tab5 = New-Object System.Windows.Forms.TabPage; $script:tab5.Text = '5. 전후 비교·리포트'
$tab6 = New-Object System.Windows.Forms.TabPage; $tab6.Text = 'C. OS 전환 안내'
foreach ($t in @($tab1, $tab2, $tab3, $tab4, $script:tab5, $tab6)) { $t.BackColor = [System.Drawing.Color]::White; [void]$script:tabs.TabPages.Add($t) }

$form.Controls.Add($script:tabs); $form.Controls.Add($header); $form.Controls.Add($script:lblStatus)

# ---------- 탭1 진단 ----------
$btnDiag = New-Btn '진단 시작' 20 16 150 44 $true
$lblScore = New-Lbl '건강점수  —' 190 12 300 36
$lblScore.Font = New-Object System.Drawing.Font('Malgun Gothic', 18, [System.Drawing.FontStyle]::Bold)
$lblWhy = New-Lbl '버튼을 누르면 CPU·메모리·저장장치·부팅시간·시작프로그램을 자동으로 조사합니다. (10~30초)' 190 48 650 40
$lblWhy.ForeColor = [System.Drawing.Color]::DimGray
$lvDiag = New-LV 20 96 830 410 @(@('항목', 150), @('결과', 540), @('판정', 120))
$btnNext1 = New-Btn '다음: 질문 3개 →' 670 520 180 40 $true; $btnNext1.Enabled = $false
$tab1.Controls.AddRange(@($btnDiag, $lblScore, $lblWhy, $lvDiag, $btnNext1))

function Show-Diagnosis {
    $d = $script:Diag
    $lvDiag.Items.Clear()
    foreach ($r in (Get-DiagRows $d)) { Add-LVRow $lvDiag @($r[0], $r[1], $r[2]) $r[3] }
    $lblScore.Text = "건강점수  $($d.Score)점  ($($d.Grade))"
    $lblScore.ForeColor = switch ($d.Grade) { '쌩쌩' { $C_GREEN } '보통' { $C_ORANGE } default { $C_RED } }
    $lblWhy.Text = if (@($d.Why).Count -gt 0) { '원인: ' + ($d.Why -join ' · ') } else { '큰 문제가 없습니다.' }
}

$btnDiag.Add_Click({
        $btnDiag.Enabled = $false
        Set-Status '진단 중... (10~30초)'
        $form.Cursor = 'WaitCursor'
        try {
            $script:Diag = Get-Diagnosis
            Load-Baseline
            if (-not $script:Baseline) { Save-Baseline }
            Show-Diagnosis
            Fill-ActionLists
            Fill-Compare
            $btnNext1.Enabled = $true
            Set-Status "진단 완료 ($($script:Diag.Time))"
        } catch {
            Set-Status ('진단 중 오류: ' + $_.Exception.Message)
        } finally { $form.Cursor = 'Default'; $btnDiag.Enabled = $true; $btnDiag.Text = '다시 진단' }
    })
$btnNext1.Add_Click({ $script:tabs.SelectedTab = $tab2 })

# ---------- 탭2 질문 ----------
$g1 = New-Object System.Windows.Forms.GroupBox; $g1.Text = '① 이 컴퓨터로 주로 무엇을 하나요? (여러 개 선택)'; $g1.Location = New-Object System.Drawing.Point(20, 16); $g1.Size = New-Object System.Drawing.Size(830, 130); $g1.Font = $fontBold
$script:chkUseWeb = New-Chk '웹 검색·유튜브·카카오톡 웹' 20 30 400 $true
$script:chkUseDoc = New-Chk '한글(HWP)·엑셀 문서 작업' 20 60 400 $false
$script:chkUseBank = New-Chk '인터넷등기소·은행·홈택스 (보안프로그램 필요)' 20 90 500 $false
foreach ($c in @($script:chkUseWeb, $script:chkUseDoc, $script:chkUseBank)) { $c.Font = $fontBase; $g1.Controls.Add($c) }

$g2 = New-Object System.Windows.Forms.GroupBox; $g2.Text = '② 부품 교체 예산은?'; $g2.Location = New-Object System.Drawing.Point(20, 160); $g2.Size = New-Object System.Drawing.Size(830, 70); $g2.Font = $fontBold
$script:rbB0 = New-Object System.Windows.Forms.RadioButton; $script:rbB0.Text = '0원 (청소만)'; $script:rbB0.Location = New-Object System.Drawing.Point(20, 30); $script:rbB0.Size = New-Object System.Drawing.Size(180, 26); $script:rbB0.Checked = $true
$script:rbB5 = New-Object System.Windows.Forms.RadioButton; $script:rbB5.Text = '5만원까지'; $script:rbB5.Location = New-Object System.Drawing.Point(220, 30); $script:rbB5.Size = New-Object System.Drawing.Size(180, 26)
$script:rbB10 = New-Object System.Windows.Forms.RadioButton; $script:rbB10.Text = '10만원까지'; $script:rbB10.Location = New-Object System.Drawing.Point(420, 30); $script:rbB10.Size = New-Object System.Drawing.Size(180, 26)
foreach ($c in @($script:rbB0, $script:rbB5, $script:rbB10)) { $c.Font = $fontBase; $g2.Controls.Add($c) }

$g3 = New-Object System.Windows.Forms.GroupBox; $g3.Text = '③ 중요한 자료(사진·문서·공동인증서)가 이 컴퓨터에만 있나요?'; $g3.Location = New-Object System.Drawing.Point(20, 244); $g3.Size = New-Object System.Drawing.Size(830, 70); $g3.Font = $fontBold
$script:rbD1 = New-Object System.Windows.Forms.RadioButton; $script:rbD1.Text = '예, 여기에만 있어요'; $script:rbD1.Location = New-Object System.Drawing.Point(20, 30); $script:rbD1.Size = New-Object System.Drawing.Size(200, 26)
$script:rbD2 = New-Object System.Windows.Forms.RadioButton; $script:rbD2.Text = '아니요, 백업돼 있어요'; $script:rbD2.Location = New-Object System.Drawing.Point(240, 30); $script:rbD2.Size = New-Object System.Drawing.Size(200, 26)
$script:rbD3 = New-Object System.Windows.Forms.RadioButton; $script:rbD3.Text = '모르겠어요'; $script:rbD3.Location = New-Object System.Drawing.Point(460, 30); $script:rbD3.Size = New-Object System.Drawing.Size(200, 26); $script:rbD3.Checked = $true
foreach ($c in @($script:rbD1, $script:rbD2, $script:rbD3)) { $c.Font = $fontBase; $g3.Controls.Add($c) }

$btnMakeRx = New-Btn '처방전 만들기 →' 670 520 180 40 $true
$lblQ = New-Lbl '먼저 [1. 진단]을 실행해야 처방전을 만들 수 있습니다.' 20 330 830 40; $lblQ.ForeColor = [System.Drawing.Color]::DimGray
$tab2.Controls.AddRange(@($g1, $g2, $g3, $lblQ, $btnMakeRx))

function Make-Rx {
    $use = @{ Web = $script:chkUseWeb.Checked; Doc = $script:chkUseDoc.Checked; Bank = $script:chkUseBank.Checked }
    $budget = if ($script:rbB0.Checked) { 0 } elseif ($script:rbB5.Checked) { 5 } else { 10 }
    $data = if ($script:rbD1.Checked -or $script:rbD3.Checked) { 'yes' } else { 'no' }
    $script:Rx = Build-Prescription $script:Diag $use $budget $data
    Show-Rx
}

function Show-Rx {
    $rx = $script:Rx; $rtb = $script:rtbRx
    $rtb.Clear()
    $add = {
        param([string]$t, $color, [bool]$bold, [float]$size)
        $rtb.SelectionStart = $rtb.TextLength
        $style = if ($bold) { [System.Drawing.FontStyle]::Bold } else { [System.Drawing.FontStyle]::Regular }
        $rtb.SelectionFont = New-Object System.Drawing.Font('Malgun Gothic', $size, $style)
        $rtb.SelectionColor = $(if ($color) { $color } else { $C_CHAR })
        $rtb.AppendText($t + "`n")
    }
    & $add $rx.Summary $C_CHAR $true 12
    & $add '' $null $false 6
    & $add 'A. 0원 청소 — [4. 처방 A 실행] 탭에서 버튼 하나로 자동 적용' $C_BRAND $true 11.5
    foreach ($l in $rx.A) { & $add ('  • ' + $l) $null $false 10 }
    & $add '' $null $false 6
    & $add 'B. 부품 교체 (SSD·메모리)' $C_BRAND $true 11.5
    foreach ($l in $rx.B) { if ($l -eq '') { & $add '' $null $false 5 } else { & $add ('  ' + $l) $null $false 10 } }
    & $add '' $null $false 6
    & $add 'C. 운영체제 전환 (ChromeOS Flex / Linux Mint)' $C_BRAND $true 11.5
    foreach ($l in $rx.C) { & $add ('  • ' + $l) $(if ($l -match '^(비추천|불가)') { $C_RED } elseif ($l -match '^추천') { $C_GREEN } else { $null }) $false 10 }
    $rtb.SelectionStart = 0; $rtb.ScrollToCaret()
}

$btnMakeRx.Add_Click({
        if (-not $script:Diag) { [System.Windows.Forms.MessageBox]::Show('먼저 [1. 진단] 탭에서 [진단 시작]을 눌러 주세요.', '안내') | Out-Null; $script:tabs.SelectedTab = $tab1; return }
        Make-Rx
        $script:tabs.SelectedTab = $tab3
        Set-Status '처방전 완성'
    })

# ---------- 탭3 처방전 ----------
$script:rtbRx = New-Object System.Windows.Forms.RichTextBox
$script:rtbRx.Location = New-Object System.Drawing.Point(20, 16); $script:rtbRx.Size = New-Object System.Drawing.Size(830, 490)
$script:rtbRx.ReadOnly = $true; $script:rtbRx.BackColor = [System.Drawing.Color]::White; $script:rtbRx.BorderStyle = 'FixedSingle'
$script:rtbRx.Text = '[2. 질문 3개]에서 [처방전 만들기]를 누르면 여기에 처방전이 나옵니다.'
$btnGoA = New-Btn '처방 A 실행하러 가기 →' 640 520 210 40 $true
$btnGoC = New-Btn 'C. OS 전환 안내' 470 520 160 40 $false
$btnRep3 = New-Btn '처방 리포트 저장' 20 520 170 40 $false
$tab3.Controls.AddRange(@($script:rtbRx, $btnGoA, $btnGoC, $btnRep3))
$btnGoA.Add_Click({ $script:tabs.SelectedTab = $tab4 })
$btnGoC.Add_Click({ $script:tabs.SelectedTab = $tab6 })
$btnRep3.Add_Click({ Save-Report })

# ---------- 탭4 처방 A 실행 ----------
$l41 = New-Lbl '시작프로그램  (체크 = 끄기, 삭제가 아니라 [끄기]라 언제든 되돌림)' 20 10 420 22; $l41.Font = $fontBold
$script:clbStartup = New-Object System.Windows.Forms.CheckedListBox
$script:clbStartup.Location = New-Object System.Drawing.Point(20, 34); $script:clbStartup.Size = New-Object System.Drawing.Size(420, 250); $script:clbStartup.CheckOnClick = $true; $script:clbStartup.HorizontalScrollbar = $true
$l42 = New-Lbl '불필요한 기본 앱  (체크 = 제거, Store에서 재설치 가능)' 460 10 390 22; $l42.Font = $fontBold
$script:clbBloat = New-Object System.Windows.Forms.CheckedListBox
$script:clbBloat.Location = New-Object System.Drawing.Point(460, 34); $script:clbBloat.Size = New-Object System.Drawing.Size(390, 250); $script:clbBloat.CheckOnClick = $true
$script:chkTemp = New-Chk '임시파일 청소' 20 294 200 $true
$script:chkRecycle = New-Chk '휴지통 비우기' 230 294 200 $true
$script:chkPower = New-Chk '전원 모드 고성능' 440 294 200 $true
$script:chkVisual = New-Chk '시각 효과 성능 우선' 650 294 200 $true
$script:chkDefrag = New-Chk '드라이브 최적화(SSD TRIM / HDD 조각모음, 별도 창)' 20 322 500 $true
$script:btnApply = New-Btn '선택 항목 실행 (복원지점 자동 생성)' 20 356 330 42 $true
$btnUndo = New-Btn '되돌리기' 360 356 120 42 $false
$lblA = New-Lbl '※ 서비스·레지스트리 삭제 같은 위험한 작업은 하지 않습니다.' 490 366 360 24; $lblA.ForeColor = [System.Drawing.Color]::DimGray
$script:txtLog = New-Object System.Windows.Forms.TextBox
$script:txtLog.Multiline = $true; $script:txtLog.ScrollBars = 'Vertical'; $script:txtLog.ReadOnly = $true
$script:txtLog.Location = New-Object System.Drawing.Point(20, 408); $script:txtLog.Size = New-Object System.Drawing.Size(830, 150); $script:txtLog.BackColor = [System.Drawing.Color]::FromArgb(250, 250, 250)
$tab4.Controls.AddRange(@($l41, $script:clbStartup, $l42, $script:clbBloat, $script:chkTemp, $script:chkRecycle, $script:chkPower, $script:chkVisual, $script:chkDefrag, $script:btnApply, $btnUndo, $lblA, $script:txtLog))
if (-not $script:IsAdmin) { $script:chkDefrag.Checked = $false; $script:chkPower.Checked = $false }

function Fill-ActionLists {
    $script:clbStartup.Items.Clear(); $script:StartupView = @()
    $order = @($script:StartupItems | Where-Object { $_.Enabled } | Sort-Object @{ Expression = { switch ($_.Category) { 'off' { 0 } 'normal' { 1 } default { 2 } } } }, Name)
    foreach ($it in $order) {
        $tag = switch ($it.Category) { 'off' { '[끄기 추천] ' } 'keep' { '[유지 권장] ' } default { '' } }
        $script:StartupView += $it
        $idx = $script:clbStartup.Items.Add("$tag$($it.Name)   — $($it.Location)")
        $script:clbStartup.SetItemChecked($idx, ($it.Category -eq 'off'))
    }
    if ($order.Count -eq 0) { [void]$script:clbStartup.Items.Add('(켜진 시작프로그램 없음)'); $script:StartupView += $null }
    $script:clbBloat.Items.Clear(); $script:BloatView = @()
    foreach ($b in @($script:Diag.Bloat)) {
        if (-not $b) { continue }
        $script:BloatView += $b
        $idx = $script:clbBloat.Items.Add("$($b.Label)   ($($b.Name))")
        $script:clbBloat.SetItemChecked($idx, $true)
    }
    if ($script:BloatView.Count -eq 0) { [void]$script:clbBloat.Items.Add('(제거할 기본 앱 없음)'); $script:BloatView += $null }
    if ($script:Diag.IsLaptop) { $script:chkPower.Checked = $false }
    $script:chkDefrag.Text = if ($script:Diag.DiskKind -eq 'SSD') { '드라이브 최적화 (SSD TRIM, 몇 분, 별도 창)' } else { '드라이브 최적화 (하드디스크 조각모음, 30분~수 시간, 별도 창)' }
}
# 안내용 빈 항목은 체크되지 않게
$script:clbStartup.Add_ItemCheck({ param($s, $e) if ($null -eq $script:StartupView[$e.Index]) { $e.NewValue = 'Unchecked' } })
$script:clbBloat.Add_ItemCheck({ param($s, $e) if ($null -eq $script:BloatView[$e.Index]) { $e.NewValue = 'Unchecked' } })

$script:btnApply.Add_Click({
        if (-not $script:Diag) { [System.Windows.Forms.MessageBox]::Show('먼저 [1. 진단]을 실행하세요.') | Out-Null; return }
        Invoke-PrescriptionA
    })
$btnUndo.Add_Click({ Invoke-Undo })

# ---------- 탭5 전후 비교·리포트 ----------
$lvCmp = New-LV 20 16 830 300 @(@('항목', 170), @('처음 진단', 220), @('지금', 220), @('변화', 200))
$lblCmp = New-Lbl '처음 진단한 상태를 기준으로 저장해 두고 비교합니다. 처방 후 컴퓨터를 재시작하고 다시 실행하면 부팅시간 변화도 보입니다.' 20 324 830 44
$lblCmp.ForeColor = [System.Drawing.Color]::DimGray
$btnReport = New-Btn '처방 리포트 저장 (바탕화면, 인쇄·PDF용)' 20 380 340 44 $true
$btnReDiag = New-Btn '다시 진단' 370 380 140 44 $false
$btnRebase = New-Btn '기준 새로 잡기' 520 380 150 44 $false
$script:tab5.Controls.AddRange(@($lvCmp, $lblCmp, $btnReport, $btnReDiag, $btnRebase))

function Fill-Compare {
    $lvCmp.Items.Clear()
    $rows = Get-CompareRows
    foreach ($r in $rows) {
        $lv = if ($r[3] -match '개선') { 'green' } elseif ($r[3] -match '악화') { 'red' } else { '' }
        Add-LVRow $lvCmp $r $lv
    }
    if ($script:Baseline) {
        $extra = if ($script:Baseline.AppliedAt) { " · 처방 실행: $($script:Baseline.AppliedAt)" } else { '' }
        $lblCmp.Text = "기준(처음 진단): $($script:Baseline.Time)$extra · 지금: $($script:Diag.Time)`n처방 후 컴퓨터를 재시작하고 다시 실행하면 부팅시간 변화도 보입니다."
    }
}
$btnReport.Add_Click({ Save-Report })
$btnReDiag.Add_Click({ $script:tabs.SelectedTab = $tab1; $btnDiag.PerformClick() })
$btnRebase.Add_Click({
        if (-not $script:Diag) { return }
        if ([System.Windows.Forms.MessageBox]::Show('지금 상태를 새 기준(처음 진단)으로 저장할까요?', '기준 새로 잡기', 'YesNo') -eq 'Yes') { Save-Baseline -Force; Fill-Compare }
    })

# ---------- 탭6 C. OS 전환 안내 ----------
$l61 = New-Lbl 'ChromeOS Flex / Linux Mint 설치 전 백업 체크리스트 — 모두 체크해야 설치 안내가 열립니다.' 20 14 830 24; $l61.Font = $fontBold; $l61.ForeColor = $C_RED
$bk = @(
    '문서·사진·다운로드 폴더를 USB 또는 클라우드(네이버 MYBOX·구글 드라이브)에 복사했다',
    '크롬 즐겨찾기·비밀번호를 구글 계정에 동기화했다',
    '공동인증서(구 공인인증서)를 USB나 휴대폰으로 옮겼다',
    '8GB 이상 USB 메모리를 준비했다 (안의 자료도 지워짐)',
    '설치하면 이 컴퓨터의 모든 자료와 윈도우가 지워진다는 것을 이해했다'
)
$script:bkChecks = @()
$y = 44
foreach ($t in $bk) { $c = New-Chk $t 30 $y 800 $false; $script:bkChecks += $c; $tab6.Controls.Add($c); $y += 30 }
$btnFlex = New-Btn 'ChromeOS Flex 설치 안내 열기' 30 ($y + 8) 280 42 $true; $btnFlex.Enabled = $false
$btnMint = New-Btn 'Linux Mint 설치 안내 열기' 320 ($y + 8) 250 42 $false; $btnMint.Enabled = $false
$script:txtC = New-Object System.Windows.Forms.TextBox
$script:txtC.Multiline = $true; $script:txtC.ReadOnly = $true; $script:txtC.ScrollBars = 'Vertical'; $script:txtC.BackColor = [System.Drawing.Color]::FromArgb(250, 250, 250)
$script:txtC.Location = New-Object System.Drawing.Point(30, ($y + 60)); $script:txtC.Size = New-Object System.Drawing.Size(820, (560 - ($y + 60)))
$script:txtC.Text = '체크리스트를 모두 확인하면 단계별 설치 안내가 여기에 나옵니다.'
$tab6.Controls.AddRange(@($l61, $btnFlex, $btnMint, $script:txtC))
foreach ($c in $script:bkChecks) {
    $c.Add_CheckedChanged({
            $all = @($script:bkChecks | Where-Object { -not $_.Checked }).Count -eq 0
            $btnFlex.Enabled = $all; $btnMint.Enabled = $all
        })
}
function Get-KeyHint { if ($script:Diag) { return (Get-BootMenuKey $script:Diag.Manufacturer) } else { return 'F12 / F11 / F10 / ESC 중 하나' } }
$btnFlex.Add_Click({
        $script:txtC.Text = @"
[ChromeOS Flex 설치 순서]  — 약 30~40분

1. (다른 컴퓨터 또는 이 컴퓨터의) 크롬 브라우저에서 '크롬북 복구 유틸리티' 확장 프로그램을 설치합니다.
2. 유틸리티 실행 → [시작하기] → [목록에서 모델 선택] → 제조업체 'Google ChromeOS Flex' → 제품 'ChromeOS Flex' 선택.
3. USB 메모리를 고르고 [지금 만들기] → 완료될 때까지 기다립니다(10~20분).
4. 이 컴퓨터에 USB를 꽂고 전원을 켜면서 부팅 메뉴 키를 연타합니다.
   → 이 컴퓨터의 부팅 메뉴 키: $(Get-KeyHint)
5. USB를 선택해 부팅 → 처음에는 [사용해 보기]로 와이파이·소리·화면이 잘 되는지 확인합니다.
6. 문제 없으면 [ChromeOS Flex 설치] → 모든 자료 삭제 확인 → 설치(약 20분).
7. 재부팅 후 USB를 빼고 구글 계정으로 로그인하면 끝.

※ 부팅이 안 되면 BIOS에서 'Secure Boot'·'Fast Boot'를 잠시 끄세요.
※ 구글이 공식 확인한 '인증 모델' 목록에 없는 PC도 대부분 작동하지만, [사용해 보기]에서 꼭 먼저 확인하세요.
"@
        Start-Process 'https://chromeenterprise.google/os/chromeosflex/'
    })
$btnMint.Add_Click({
        $script:txtC.Text = @"
[Linux Mint 설치 순서]  — 약 40분

1. linuxmint.com 에서 'Cinnamon' 판(메모리 4GB 이상) 또는 'Xfce' 판(메모리 2~4GB)을 내려받습니다(ISO 파일).
2. Rufus(rufus.ie) 프로그램으로 ISO를 USB 메모리에 굽습니다.
3. 이 컴퓨터에 USB를 꽂고 전원을 켜면서 부팅 메뉴 키를 연타합니다.
   → 이 컴퓨터의 부팅 메뉴 키: $(Get-KeyHint)
4. USB로 부팅하면 설치 없이 바로 체험 화면이 나옵니다 → 와이파이·소리 확인.
5. 바탕화면의 [Install Linux Mint] → 언어 '한국어' → [디스크를 지우고 Linux Mint 설치].
6. 재부팅 후 [업데이트 관리자]로 업데이트하고, 한글 입력은 오른쪽 아래 입력기에서 설정합니다.

※ 한글(HWP)은 웹용 한컴독스, 문서는 LibreOffice(기본 설치)로 대체합니다.
"@
        Start-Process 'https://linuxmint.com/download.php'
        Start-Process 'https://rufus.ie/ko/'
    })

# ---------- 시작 ----------
$form.Add_Shown({
        $form.Activate()
        Load-Baseline
        if (Test-Path $script:UndoFile) { Write-Log '이전 처방 A 실행 기록이 있습니다. [되돌리기]로 원래 설정을 복구할 수 있습니다.' }
    })
[void]$form.ShowDialog()
