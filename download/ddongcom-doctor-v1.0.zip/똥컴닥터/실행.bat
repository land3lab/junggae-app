@echo off
rem Ddongcom Doctor launcher - Land3 Lab
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0DdongcomDoctor.ps1"
